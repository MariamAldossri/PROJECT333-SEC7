/*
  Requirement: Populate the weekly detail page and discussion forum.

  Instructions:
  1. Link this file to `details.html` using:
     <script src="details.js" defer></script>

  2. In `details.html`, add the following IDs:
     - To the <h1>: `id="week-title"`
     - To the start date <p>: `id="week-start-date"`
     - To the description <p>: `id="week-description"`
     - To the "Exercises & Resources" <ul>: `id="week-links-list"`
     - To the <div> for comments: `id="comment-list"`
     - To the "Ask a Question" <form>: `id="comment-form"`
     - To the <textarea>: `id="new-comment-text"`

  3. Implement the TODOs below.
*/

// --- Global Data Store ---
let currentWeekId = null;
let currentComments = [];

// --- Element Selections ---
const weekTitle = document.getElementById("week-title");
const startDate = document.getElementById("week-start-date");
const weekDescription = document.getElementById("week-description");
const weekList = document.getElementById("week-links-list");
const commentsDiv = document.getElementById("comment-list");
const commentForm = document.getElementById("comment-form");
const newCommentTextarea = document.getElementById("new-comment");

// --- Functions ---

function getWeekIdFromURL() {
  const queryString = window.location.search;
  const id = new URLSearchParams(queryString).get("id");
  currentWeekId = id;
  return id;
}

function renderWeekDetails(week) {
  weekTitle.innerText = week.title;
  startDate.innerText = `Starts on: ${week.startDate}`;
  weekDescription.innerText = week.description;
  weekList.innerHTML = "";

  if (Array.isArray(week.links)) {
    week.links.forEach((link) => {
      if (!link) return;
      const listElement = document.createElement("li");
      const aElement = document.createElement("a");
      aElement.href = link;
      aElement.target = "_blank";
      aElement.classList.add("resource-link");
      aElement.innerText = link;
      listElement.appendChild(aElement);
      weekList.appendChild(listElement);
    });
  }
}

function createCommentArticle(comment) {
  const commentArticle = document.createElement("article");
  commentArticle.classList.add("comment-card");

  const articleComment = document.createElement("p");
  articleComment.classList.add("comment-text");
  articleComment.innerText = comment.text;

  const articleFooter = document.createElement("footer");
  articleFooter.classList.add("comment-footer");

  const spanAuthor = document.createElement("span");
  spanAuthor.classList.add("comment-author");
  spanAuthor.innerText = `Posted by: ${comment.author}`;

  articleFooter.appendChild(spanAuthor);
  commentArticle.appendChild(articleComment);
  commentArticle.appendChild(articleFooter);

  return commentArticle;
}

function renderComments() {
  commentsDiv.innerHTML = "";
  currentComments.forEach((comment) => {
    commentsDiv.appendChild(createCommentArticle(comment));
  });
}

function handleAddComment(event) {
  event.preventDefault();

  const commentText = newCommentTextarea.value;

  if (commentText.trim().length === 0) {
    return;
  }

  const commentObj = { author: "Student", text: commentText.trim() };
  currentComments.push(commentObj);

  renderComments();
  event.target.reset();
  customAddCommentToDB(commentObj);
}

async function customAddCommentToDB(comment) {
  try {
    const response = await fetch(
      `/src/weekly/api/index.php?resource=comments`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          week_id: currentWeekId,
          author: comment.author,
          text: comment.text,
        }),
      }
    );
    if (!response.ok) throw new Error();

    const json = await response.json();
    if (json && json.data) {
      currentComments[currentComments.length - 1] = json.data;
    }
  } catch (err) {
    console.log("Error adding comment to DB:", err);
  }
}

function handleDeleteComment(event) {
  const commentCard = event.target.closest(".comment-card");
  const commentText = commentCard.querySelector(".comment-text").innerText;

  const commentIndex = currentComments.findIndex(
    (comment) => comment.text === commentText
  );

  if (commentIndex !== -1) {
    customDeleteCommentFromDB(currentComments[commentIndex].id);
    currentComments.splice(commentIndex, 1);
    renderComments();
  }
}

async function customDeleteCommentFromDB(commentId) {
  try {
    const response = await fetch(
      `/src/weekly/api/index.php?resource=comments&id=${commentId}`,
      {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: commentId }),
      }
    );
    if (!response.ok) throw new Error();
  } catch (err) {
    console.log("Error deleting comment from DB:", err);
  }
}

async function initializePage() {
  const weekId = getWeekIdFromURL();

  if (weekId == null) {
    weekTitle.innerText = "Week not found.";
    return;
  }

  let week = null;
  let comments = [];

  try {
    const commentsResponse = await fetch(
      `/src/weekly/api/index.php?resource=comments&week_id=${weekId}`
    );
    const commentsJson = await commentsResponse.json();
    comments = commentsJson.data || [];

    const weekResponse = await fetch(
      `/src/weekly/api/index.php?resource=weeks&week_id=${weekId}`
    );
    const weekJson = await weekResponse.json();
    const data = weekJson.data;

    week = {
      id: data.id,
      title: data.title,
      startDate: data.start_date,
      description: data.description,
      links: data.links,
    };
  } catch (err) {
    console.log("Error fetching week or comments from API:", err);

    const weeks = await (await fetch("api/weeks.json")).json();
    const weekComments = await (await fetch("api/comments.json")).json();

    week = weeks.filter((w) => w.id == weekId)[0];
    comments = weekComments[weekId] || [];
  }

  if (week == null) {
    weekTitle.innerText = "Error: This week does not exist";
    return;
  }

  currentComments = [];
  currentComments.push(...comments);

  renderWeekDetails(week);
  renderComments();

  commentForm.addEventListener("submit", handleAddComment);

  commentsDiv.addEventListener("click", function (event) {
    if (
      event.target &&
      event.target.classList.contains("delete-comment-btn")
    ) {
      handleDeleteComment(event);
    }
  });
}

initializePage();
